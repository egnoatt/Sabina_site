import ServiziContent from '@/components/ServiziContent';

export const metadata = {
  title: 'Servizi Offerti | Sabina Scattola - Psicologa e Psicoterapeuta',
  description: 'Descrizione breve dei servizi offerti dalla Dott.ssa Sabina Scattola.'
};

export default function Servizi() {
  return <ServiziContent />;
}